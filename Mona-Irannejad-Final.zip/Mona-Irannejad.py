#!/usr/bin/env python
# coding: utf-8

# In[278]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# In[279]:


#import table 1
df1 = pd.read_csv ('UNT1.csv')
df1


# In[280]:


# drop the empty cells and the first raw since the years are in the column labels
df1 = df1.drop(['Unnamed: 23','Unnamed: 24', 'Unnamed: 25', 'Unnamed: 26', 'Unnamed: 27', 
                'Unnamed: 28', 'Unnamed: 29','Unnamed: 30', 'Unnamed: 31',
                'Unnamed: 32', 'Unnamed: 33', 'Unnamed: 34', 'Unnamed: 35',
                'Unnamed: 36', 'Unnamed: 37', 'Unnamed: 38', 'Unnamed: 39',
                'Unnamed: 40', 'Unnamed: 41', 'Unnamed: 42'], axis=1)
df1 = df1.drop([0])
df1 = df1.reset_index(drop=True)
df1


# In[281]:


#renamed the columns
#Both = T, male = M, female= F
dict = {'International migrant stock at mid-year (both sexes)1990':'T1990',
        'International migrant stock at mid-year (both sexes)1995': 'T1995',
        'International migrant stock at mid-year (both sexes)2000': 'T2000',
        'International migrant stock at mid-year (both sexes)2005': 'T2005',
        'International migrant stock at mid-year (both sexes)2010': 'T2010',
        'International migrant stock at mid-year (both sexes)2015': 'T2015',
        'International migrant stock at mid-year (male)1990':'M1990',
        'International migrant stock at mid-year (male)1995': 'M1995',
        'International migrant stock at mid-year (male)2000': 'M2000',
        'International migrant stock at mid-year (male)2005': 'M2005',
        'International migrant stock at mid-year (male)2010': 'M2010',
        'International migrant stock at mid-year (male)2015': 'M2015',
        'International migrant stock at mid-year (female)1990': 'F1990',
        'International migrant stock at mid-year (female)1995':'F1995',
        'International migrant stock at mid-year (female)2000': 'F2000', 
        'International migrant stock at mid-year (female)2005': 'F2005', 
        'International migrant stock at mid-year (female)2010': 'F2010',
        'International migrant stock at mid-year (female)2015': 'F2015'
       }
df1 = df1.rename(columns=dict)
df1.head()


# In[282]:


#tidydata p1: values should not be stored in columns as variables
df1 = df1.melt(id_vars=['Sort order', 'Major area, region, country or area of destination', 'Notes',
                        'Country code', 'Type of data (a)'], var_name=["yearsex"],value_name='International migrant stock')


# In[283]:


# tidydata p2: multiple variables in once column. sex and year should be separated.
df1=(df1.assign(gender = lambda x: x.yearsex.str[0].astype(str), year = lambda x: x.yearsex.str[1:].astype(int)).drop("yearsex",axis=1))
df1


# In[284]:


#Replace "T","M","F" with genders
df1 = (df1.replace(to_replace =["T","M","F"],value =["Both","Male","Female"]))


# In[285]:


#reindex the columns
df1 = df1.reindex(columns=['Sort order', 'Major area, region, country or area of destination', 'Notes',
                           'Country code', 'Type of data (a)', 'year','gender','International migrant stock'])
df1


# In[286]:


#save the clean dataset as a csv file
df1.to_csv("Clean_UNT1")


# In[ ]:





# In[287]:


#import table 2
df2 = pd.read_csv ('UNT2.csv')
df2


# In[288]:


##Repeat all the steps that I did for df1
df2 = df2.drop([0])
df2 = df2.reset_index(drop=True)

dict = {'Total population of both sexes at mid-year (thousands)1990':'T1990',
        'Total population of both sexes at mid-year (thousands)1995': 'T1995',
        'Total population of both sexes at mid-year (thousands)2000': 'T2000',
        'Total population of both sexes at mid-year (thousands)2005': 'T2005',
        'Total population of both sexes at mid-year (thousands)2010': 'T2010',
        'Total population of both sexes at mid-year (thousands)2015': 'T2015',
        'Total male population at mid-year (thousands)1990':'M1990',
        'Total male population at mid-year (thousands)1995': 'M1995',
        'Total male population at mid-year (thousands)2000': 'M2000',
        'Total male population at mid-year (thousands)2005': 'M2005',
        'Total male population at mid-year (thousands)2010': 'M2010',
        'Total male population at mid-year (thousands)2015': 'M2015',
        'Total female population at mid-year (thousands)1990': 'F1990',
        'Total female population at mid-year (thousands)1995':'F1995',
        'Total female population at mid-year (thousands)2000': 'F2000', 
        'Total female population at mid-year (thousands)2005': 'F2005', 
        'Total female population at mid-year (thousands)2010': 'F2010',
        'Total female population at mid-year (thousands)2015': 'F2015'
       }

df2 = df2.rename(columns=dict)

df2 = df2.melt(id_vars=['Sort order', 'Major area, region, country or area of destination','Notes',
                        'Country code'], var_name=["yearsex"],value_name="Total population")
df2 = (df2.assign(gender = lambda x: x.yearsex.str[0].astype(str), year = lambda x: x.yearsex.str[1:].astype(int)).drop("yearsex",axis=1))

df2 = (df2.replace(to_replace =["T","M","F"],value =["Both","Male","Female"]))

df2 = df2.reindex(columns=['Sort order', 'Major area, region, country or area of destination', 'Notes',
                           'Country code', 'year','gender','Total population'])
df2


# In[289]:


#save the clean dataset as a csv file
df2.to_csv("Clean_UNT2")


# In[ ]:





# In[290]:


#repeat for table 3
df3 = pd.read_csv ('UNT3.csv')
df3


# In[291]:


df3 = df3.drop([0])
df3 = df3.reset_index(drop=True)

dict = {'International migrant stock as a percentage of the total population (both sexes)1990':'T1990',
        'International migrant stock as a percentage of the total population (both sexes)1995': 'T1995',
        'International migrant stock as a percentage of the total population (both sexes)2000': 'T2000',
        'International migrant stock as a percentage of the total population (both sexes)2005': 'T2005',
        'International migrant stock as a percentage of the total population (both sexes)2010': 'T2010',
        'International migrant stock as a percentage of the total population (both sexes)2015': 'T2015',
        'International migrant stock as a percentage of the total population (male)1990':'M1990',
        'International migrant stock as a percentage of the total population (male)1995': 'M1995',
        'International migrant stock as a percentage of the total population (male)2000': 'M2000',
        'International migrant stock as a percentage of the total population (male)2005': 'M2005',
        'International migrant stock as a percentage of the total population (male)2010': 'M2010',
        'International migrant stock as a percentage of the total population (male)2015': 'M2015',
        'International migrant stock as a percentage of the total population (female)1990': 'F1990',
        'International migrant stock as a percentage of the total population (female)1995':'F1995',
        'International migrant stock as a percentage of the total population (female)2000': 'F2000', 
        'International migrant stock as a percentage of the total population (female)2005': 'F2005', 
        'International migrant stock as a percentage of the total population (female)2010': 'F2010',
        'International migrant stock as a percentage of the total population (female)2015': 'F2015'
       }

df3 = df3.rename(columns=dict)

df3 = df3.melt(id_vars=['Sort order', 'Major area, region, country or area of destination','Notes',
                        'Country code','Type of data (a)'], var_name=["yearsex"],value_name="International migrant stock as a percentage of the total population")
df3 = (df3.assign(gender = lambda x: x.yearsex.str[0].astype(str), year = lambda x: x.yearsex.str[1:].astype(int)).drop("yearsex",axis=1))

df3 = (df3.replace(to_replace =["T","M","F"],value =["Both","Male","Female"]))

df3 = df3.reindex(columns=['Sort order', 'Major area, region, country or area of destination','Notes',
                           'Country code', 'Type of data (a)', 'year','gender','International migrant stock as a percentage of the total population'])
df3


# In[292]:


#save the clean dataset as a csv file
df3.to_csv("Clean_UNT3")


# In[ ]:





# In[293]:


# in table 4, we don't have sex variable. it's only for female population
df4 = pd.read_csv ('UNT4.csv')
df4 = df4.drop([0])
df4 = df4.reset_index(drop=True)
df4


# In[294]:


df4 = df4.melt(id_vars=['Sort order', 'Major area, region, country or area of destination','Notes',
                        'Country code','Type of data (a)'], var_name=["year"],value_name="Female migrants as a percentage of the international migrant stock")

df4 = (df4.assign( year = lambda x: x.year.str[-4:].astype(int)))
df4


# In[295]:


# in order to merge the tables late, I add a column for gender
df4 = (df4.assign( gender = lambda x: 'Female'))
df4


# In[296]:


#save the clean dataset as a csv file
df4.to_csv("Clean_UNT4")


# In[ ]:





# In[297]:


# table 5 
df5 = pd.read_csv ('UNT5.csv')
df5


# In[298]:


df5 = df5.drop(['Unnamed: 20', 'Unnamed: 21', 'Unnamed: 22', 'Unnamed: 23',
                'Unnamed: 24', 'Unnamed: 25', 'Unnamed: 26', 'Unnamed: 27',
                'Unnamed: 28', 'Unnamed: 29'], axis=1)
df5 = df5.drop([0])
df5 = df5.reset_index(drop=True)

dict = {'Annual rate of change of the migrant stock (both sexes)1990-1995':'T1990-1995',
        'Annual rate of change of the migrant stock (both sexes)1995-2000': 'T1995-2000',
        'Annual rate of change of the migrant stock (both sexes)2000-2005': 'T2000-2005',
        'Annual rate of change of the migrant stock (both sexes)2005-2010': 'T2005-2010',
        'Annual rate of change of the migrant stock (both sexes)2010-2015': 'T2010-2015',
        'Annual rate of change of the migrant stock (male)1990-1995':'M1990-1995',
        'Annual rate of change of the migrant stock (male)1995-2000': 'M1995-2000',
        'Annual rate of change of the migrant stock (male)2000-2005': 'M2000-2005',
        'Annual rate of change of the migrant stock (male)2005-2010': 'M2005-2010',
        'Annual rate of change of the migrant stock (male)2010-2015': 'M2010-2015',
        'Annual rate of change of the migrant stock (female)1990-1995': 'F1990-1995',
        'Annual rate of change of the migrant stock (female)1995-2000':'F1995-2000',
        'Annual rate of change of the migrant stock (female)2000-2005': 'F2000-2005', 
        'Annual rate of change of the migrant stock (female)2005-2010': 'F2005-2010', 
        'Annual rate of change of the migrant stock (female)2010-2015': 'F2010-2015',
       }

df5 = df5.rename(columns=dict)

df5 = df5.melt(id_vars=['Sort order', 'Major area, region, country or area of destination','Notes',
                        'Country code','Type of data (a)'], var_name=["yearsex"],value_name="Annual rate of change of the migrant stock")
df5 = (df5.assign(gender = lambda x: x.yearsex.str[0].astype(str), year = lambda x: x.yearsex.str[1:].astype(str)).drop("yearsex",axis=1))

df5 = (df5.replace(to_replace =["T","M","F"],value =["Both","Male","Female"]))
df5 = df5.reindex(columns=['Sort order', 'Major area, region, country or area of destination','Notes',
                           'Country code', 'Type of data (a)', 'year','gender','Annual rate of change of the migrant stock'])
df5


# In[299]:


#save the clean dataset as a csv file
df5.to_csv("Clean_UNT5")


# In[ ]:





# In[300]:


#table 6
df6 = pd.read_csv ('UNT6.csv')
df6


# In[301]:


df6 = df6.drop(['Unnamed: 22','Unnamed: 23', 'Unnamed: 24', 
                'Unnamed: 25', 'Unnamed: 26','Unnamed: 27', 
                'Unnamed: 28', 'Unnamed: 29', 'Unnamed: 30',
                'Unnamed: 31'], axis=1)
df6 = df6.drop([0])
df6 = df6.reset_index(drop=True)


# In[302]:


# split table 6 into three tables 
refugee_stock = df6[['Sort order', 'Major area, region, country or area of destination',
                                    'Notes', 'Country code', 'Type of data (a)',
                                    'Estimated refugee stock at mid-year (both sexes)1990',
                                    'Estimated refugee stock at mid-year (both sexes)1995',
                                    'Estimated refugee stock at mid-year (both sexes)2000',
                                    'Estimated refugee stock at mid-year (both sexes)2005',
                                    'Estimated refugee stock at mid-year (both sexes)2010',
                                    'Estimated refugee stock at mid-year (both sexes)2015',]]

refugee_perc = df6[['Sort order', 'Major area, region, country or area of destination',
                    'Notes', 'Country code', 'Type of data (a)',
                    'Refugees as a percentage of the international migrant stock1990',
                    'Refugees as a percentage of the international migrant stock1995',
                    'Refugees as a percentage of the international migrant stock2000',
                    'Refugees as a percentage of the international migrant stock2005',
                    'Refugees as a percentage of the international migrant stock2010',
                    'Refugees as a percentage of the international migrant stock2015']]

annualrate = df6[['Sort order', 'Major area, region, country or area of destination',
                  'Notes', 'Country code', 'Type of data (a)','Annual rate of change of the refugee stock1990-1995',
                  'Annual rate of change of the refugee stock1995-2000',
                  'Annual rate of change of the refugee stock2000-2005',
                  'Annual rate of change of the refugee stock2005-2010',
                  'Annual rate of change of the refugee stock2010-2015']]


# In[303]:


refugee_stock


# In[304]:


refugee_perc


# In[305]:


annualrate


# In[306]:


#now we have 3 separate dataset, we clean them based on tidydata principle 2 & 3, like previous dataframes
# table 6 is for both sexes and gender is not a variable. So, in order to merge the dataframes I added gender column


# In[307]:


refugee_stock = refugee_stock.melt(id_vars=['Sort order', 'Major area, region, country or area of destination','Notes',
                            'Country code','Type of data (a)'], 
                   var_name=["year"],value_name="Estimated refugee stock")

refugee_stock = (refugee_stock.assign(year = lambda x: x.year.str[-4:].astype(int)))

refugee_stock = (refugee_stock.assign( gender = lambda x: 'Both'))
refugee_stock


# In[308]:


refugee_perc = refugee_perc.melt(id_vars=['Sort order', 'Major area, region, country or area of destination','Notes',
                            'Country code','Type of data (a)'], 
                   var_name=["year"],value_name="Refugees as % of the international migrant stock")

refugee_perc = (refugee_perc.assign(year = lambda x: x.year.str[-4:].astype(int)))

refugee_perc = (refugee_perc.assign( gender = lambda x: 'Both'))

refugee_perc


# In[309]:


annualrate = annualrate.melt(id_vars=['Sort order', 'Major area, region, country or area of destination','Notes',
                            'Country code','Type of data (a)'], 
                   var_name=["year"],value_name="Annual rate of change of the refugee stock")

annualrate = (annualrate.assign(year = lambda x: x.year.str[-9:].astype(str)))

annualrate = (annualrate.assign( gender = lambda x: 'Both'))

annualrate


# In[310]:


refugee_stock.to_csv("Clean_UNT6_stock")
refugee_perc.to_csv("Clean_UNT6_percentage")
annualrate.to_csv("Clean_UNT6_annualrate") 


# In[311]:


x1 = df1[["Major area, region, country or area of destination", "year", "gender", "International migrant stock"]]
x2 = df2[["Major area, region, country or area of destination", "year", "gender", "Total population"]]
x3 = df3[["Major area, region, country or area of destination", "year", "gender", "International migrant stock as a percentage of the total population"]]
x4 = df4[["Major area, region, country or area of destination", "year", "gender", "Female migrants as a percentage of the international migrant stock"]]
x5 = df5[["Major area, region, country or area of destination", "year", "gender", "Annual rate of change of the migrant stock"]]
x6 = refugee_stock[["Major area, region, country or area of destination", "year", "gender", "Estimated refugee stock"]]
x7 = refugee_perc[["Major area, region, country or area of destination", "year", "gender", "Refugees as % of the international migrant stock"]]
x8 = annualrate[["Major area, region, country or area of destination", "year", "gender", "Annual rate of change of the refugee stock"]]


# In[312]:


x = x1.merge(x2, how='outer', on=['Major area, region, country or area of destination','year','gender'])
x = x.merge(x3, how='outer', on=['Major area, region, country or area of destination','year','gender'])
x = x.merge(x4, how='outer', on=['Major area, region, country or area of destination','year','gender'])
x = x.merge(x6, how='outer', on=['Major area, region, country or area of destination','year','gender'])
x = x.merge(x7, how='outer', on=['Major area, region, country or area of destination','year','gender'])
x1 = x5.merge(x8, how='outer', on=['Major area, region, country or area of destination','year','gender'])


# In[313]:


x.dtypes


# In[314]:


x


# In[315]:


x1


# In[316]:


x["Estimated refugee stock"].astype(str)


# In[317]:


x["International migrant stock"] = x["International migrant stock"].apply(lambda x: x.replace(" ", ""))
x["Total population"] = x["Total population"].apply(lambda x: x.replace(" ", ""))
x["Estimated refugee stock"] = x["Estimated refugee stock"].astype(str).apply(lambda x: x.replace(" ", ""))


# In[318]:


x.dtypes


# In[319]:


x2["Total population"].value_counts()


# In[320]:


x = x.replace("..", np.NaN)
x = x.replace ("NaN",np.NaN)
x1 =x1.replace("..",np.NaN)


# In[321]:


x.iloc[:,[1,3,4,5,6,7,8]] = x.replace("..", np.NaN).iloc[:,[1,3,4,5,6,7,8]].astype(float)


# In[322]:


x


# In[323]:


x.describe()


# In[324]:


x1.describe()


# In[325]:


x[x["Refugees as % of the international migrant stock"] > 100]


# In[327]:


f1 = x.groupby('year', as_index=False)['Female migrants as a percentage of the international migrant stock'].mean()
f1


# In[328]:


import numpy as np
import pandas as pd
import seaborn as sns
import plotly
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# In[329]:


sns.boxplot(data = x, y = "Female migrants as a percentage of the international migrant stock", x = "year")


# In[330]:


sns.scatterplot(data = x[x["Major area, region, country or area of destination"] == "Canada"],
               x = "year",
               y = "International migrant stock as a percentage of the total population",
               hue = "gender")


# In[331]:


sns.scatterplot(data = x1[x1["Major area, region, country or area of destination"] == "Iran (Islamic Republic of)"],
               x = "year",
               y = "Annual rate of change of the migrant stock",
               hue = "gender")


# In[332]:


sns.scatterplot(data = x1[x1["Major area, region, country or area of destination"] == "WORLD"],
               x = "year",
               y = "Annual rate of change of the migrant stock",
               hue = "gender")


# In[333]:


import seaborn as sns

df = x[x["Major area, region, country or area of destination"].isin(["Canada", "Germany", "United States of America"])].reset_index(drop = True)

sns.scatterplot(data = df, x = "year",
                y = "Female migrants as a percentage of the international migrant stock",
                hue = "Major area, region, country or area of destination")


# In[334]:


df = x.sort_values('International migrant stock as a percentage of the total population', ascending=False)
df = df[df.year == 2015.]
df = df[df.gender == "Both"]

sns.barplot(data = df.iloc[:20], x = "International migrant stock as a percentage of the total population",
            y = "Major area, region, country or area of destination")


# In[351]:


x.corr()


# In[348]:





# In[ ]:




